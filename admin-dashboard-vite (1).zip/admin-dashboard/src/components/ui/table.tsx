export const Table = ({ children }: any) => <table>{children}</table>;
export const TableBody = ({ children }: any) => <tbody>{children}</tbody>;
export const TableCell = ({ children }: any) => <td>{children}</td>;
export const TableHead = ({ children }: any) => <th>{children}</th>;
export const TableHeader = ({ children }: any) => <thead>{children}</thead>;
export const TableRow = ({ children }: any) => <tr>{children}</tr>;